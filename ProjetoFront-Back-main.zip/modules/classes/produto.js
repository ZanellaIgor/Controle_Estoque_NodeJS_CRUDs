export class Produto {
    constructor(nome, unidade, referencia, estoque, imagem) {
        this.nome = nome;
        this.unidade = unidade;
        this.referencia = referencia;
        this.estoque = estoque;
        this.imagem = imagem;
    }
}
